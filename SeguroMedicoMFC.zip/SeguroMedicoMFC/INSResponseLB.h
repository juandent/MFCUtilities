#pragma once

// #include "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Tools\MSVC\14.33.31629\atlmfc\include\afxwin.h"
#include <afxwin.h>

class INSResponseLB :
    public CListBox
{
};

