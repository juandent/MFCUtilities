#include "stdafx.h"
#include "RadioButtonGroup.h"


void test()
{
	CButton b1;
	CButton b2;
	RadioButtonGroup group({ &b1, &b2 });
}
